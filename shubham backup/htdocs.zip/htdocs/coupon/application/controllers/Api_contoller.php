<?php
	 defined('BASEPATH') OR exit('No direct script access allowed');
	 class Api_contoller extends CI_Controller
	 {
	 	function __construct()
	 	{
	 		parent::__construct();
	 		$this->load->model('ApiModel','API');
	 	}
	 	public function Get_Tokens(){
			$username = "UNWAQM";
		    $password = "WJLT";
		    $host = "https://auth.mzapi.mezzofy.com/v2/token";
		    $ch = curl_init($host);
		    $headers = array(
			'Content-Type: application/x-www-form-urlencoded',
			'account: WJLT',
			);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
		    //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,"grant_type=client_credentials");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			$return = curl_exec($ch);
			 $json = json_decode(utf8_encode($return), true);
			 $token=$json["accessToken"];
			 $token_Expiry=$json["accessTokenExpiresAt"];	
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($httpcode==200)
			{					
				$data=array('tokens'=>$token,'expire_date'=>$token_Expiry);
	 			$res=$this->API->Insert_Tokens($data);
	 			print_r($res);
	 			echo'on success';
				 $this->Get_Coupans_List($token,$token_Expiry);

			}
			else
			{
				echo"Token Not Found";
			}
			curl_close($ch);
	 	}
	 	public function Get_Coupans_List()
	 	{
	 		 $result=$this->db->get('tokens')->result();
	 		 $token=$result[0]->tokens;
	 		// $result[0]->expire_date;
		    $url = 'https://coupon.mzapi.mezzofy.com/v2';
                /* Init cURL resource */
            $curl = curl_init($url);
            // echo ' User Id: '.$id;
            curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                  // Set Here Your Requesred Headers
                     'Content-Type: application/json',
                     'Authorization: Bearer '.$token
                ),
            ));
            $result = curl_exec($curl);
             // $json = json_decode(utf8_encode($result), true);
             print_r($result);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);
	 		// $token_date =date("Y-m-d h:i:s",strtotime($token_Expiry));
	 		
	 		// if($current_time==$token_date)
	 		// {
	 		// 	echo"hit again";
	 		// }
	 		// else
	 		// {
	 		// 	echo"run as it is";
	 		// }
	 	}
	 		public function Get_Coupons_Byid(){
	 			https://coupon.mzapi.mezzofy.com/v2/
	 			$url = 'https://coupon.mzapi.mezzofy.com/v2/';
                /* Init cURL resource */
            $curl = curl_init($url);
            // echo ' User Id: '.$id;
            curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                  // Set Here Your Requesred Headers
                     'Content-Type: application/json',
                     'Authorization: Bearer '.$token
                ),
            ));
            $result = curl_exec($curl);
             // $json = json_decode(utf8_encode($result), true);
             print_r($result);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);
	 	}
 }