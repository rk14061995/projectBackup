<?php
class ApiModel extends CI_Model
{
	public function Insert_Tokens($data)
	{ 
		// $data=array('tokens'=>'newlattestwtokens74845','expire_date'=>'20/11/2020  17:20:36');
		$success=$this->db->get('tokens')->result();
		$id=$success[0]->token_id;
		if(count($success)==0)
			{
			 $this->db->insert('tokens',$data);
			 $result=$this->db->get('tokens')->result();
			   return $result;
			  // print_r($result);
			  // echo"succes";
			}
			else
			{
				$this->db->where('token_id',$id);
				$this->db->update('tokens',$data);
				$result=$this->db->get('tokens')->result();
				return $result; 
			 // print_r($result);
				// echo'update';	
			}
	}
	public function user_login($data)
	{
		$this->db->where($data);
		$success=$this->db->get('user')->result();
		if(count($success)>0)
	    {  
			return $success;
		}
		 else
	    {
	        
			return false;
		}
	}
	public function Borrower_Registration($data,$added_by,$borrower_gmail)
	{
		$this->db->where("lender_id='$added_by' AND borrower_gmail='$borrower_gmail'");
		$re=$this->db->get('borrower')->result();
		if(count($re)==0)
		{
			$results=$this->db->insert('borrower',$data);
			if($results)
			{
				return $results;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 2;
	    }
	}
	public function Lender_transaction($data)
	{
		$this->db->where($data);
		$results=$this->db->insert('transaction',$data);
		if($results)
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
	}  
	public function Lender_Debit_details($lender_id)
	{
		$this->db->where("transaction.tran_type='DEBT' AND transaction.lender_id='$lender_id'");
		$this->db->from('transaction');
		$this->db->join('user','user.user_id=transaction.lender_id');
		$this->db->join('borrower','borrower.borrower_id=transaction.borrower_id');
		return $this->db->get()->result();
		
	}  
	public function Lender_Credit_details($data)
	{
		$this->db->where("transaction.tran_type='CR' AND transaction.lender_id='$data'");
    	$this->db->from('transaction');
		$this->db->join('user','user.user_id=transaction.lender_id');
		$this->db->join('borrower','borrower.borrower_id=transaction.borrower_id');
		return $this->db->get()->result();
		
	}  
	public function Get_Borrower_details($lender_id)
	{
        $this->db->where('lender_id',$lender_id);
        return $this->db->get('borrower')->result();
	}  
	public function Update_Lender_transaction($data,$condition)
	{
		$this->db->where($condition);
		$results=$this->db->update('transaction',$data);
		if($results)
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
	}  
}